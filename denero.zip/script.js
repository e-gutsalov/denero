$(document).keydown(function(e) {

	if (e.key === "ArrowLeft" || e.keyCode === 37) {
		alert('Нажата клавиша ArrowLeft');
	}
    if (e.key === "ArrowUp" || e.keyCode === 38) {
		alert('Нажата клавиша ArrowUp');
    }
    if (e.key === "ArrowRight" || e.keyCode === 39) {
		alert('Нажата клавиша ArrowRight');
    }
    if (e.key === "ArrowDown" || e.keyCode === 40) {
		alert('Нажата клавиша ArrowDown');
    }

});
